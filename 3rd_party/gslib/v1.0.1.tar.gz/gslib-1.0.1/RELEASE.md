# Release 1.0.0

## Major Features and Improvements

## Backwards-Incompatible Changes 

## Bug Fixes and Other Changes

## Thanks to our Contributors
This release contains contributions from: James Lottes, Paul Fischer, Stefan Kerkemeier
We are also grateful to all who filed issues or helped resolve them, asked and answered questions, and were part of inspiring discussions.
